const fs = require("fs");

const getNotes = function () {
  return "Your notes...";
};

const listnotes = function () {
  let notes = loadNotes();
  notes.forEach((note) => {
    console.log(note);
  });
};
const addNote = function (title, body) {
  const notes = loadNotes();
  const duplicateNotes = notes.filter(function (note) {
    return note.title === title;
  });

  if (duplicateNotes.length === 0) {
    notes.push({
      title: title,
      body: body,
    });
    saveNotes(notes);
    console.log("New note added!");
  } else {
    console.log("Note title taken!");
  }
};

const readNote = function (title) {
  const notes = loadNotes();
  const note = notes.find((note) => note.title == title);
  if (note) {
    console.log("Note found", title);
  } else {
    console.log("note not found");
  }
};

const saveNotes = function (notes) {
  const dataJSON = JSON.stringify(notes);
  fs.writeFileSync("notes.json", dataJSON);
};

const loadNotes = function () {
  try {
    const dataBuffer = fs.readFileSync("notes.json");
    const dataJSON = dataBuffer.toString();
    return JSON.parse(dataJSON);
  } catch (e) {
    return [];
  }
};

const removeNote = function (title) {
  const notes = loadNotes();
  const newArr = notes.filter(function (note) {
    return note.title !== title;
  });

  if (notes.length > newArr.length) {
    console.log(`Note with ${title} title removed`);
  } else {
    console.log(`Note with ${title} title is not present`);
  }
  saveNotes(newArr);
};

module.exports = {
  getNotes: getNotes,
  addNote: addNote,
  removeNote: removeNote,
  listnotes: listnotes,
  readNote: readNote,
};
