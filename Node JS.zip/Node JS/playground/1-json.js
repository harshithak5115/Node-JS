let fs = require("fs");

let JSONbuffer = fs.readFileSync("1-json.json");
JSONbuffer = JSONbuffer.toString();
let parsedJSON = JSON.parse(JSONbuffer);
