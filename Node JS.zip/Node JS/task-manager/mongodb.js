const mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient;

const ConnectionURl = "mongodb://127.0.0.1:27017";

const DatabaseName = "task-manager";

MongoClient.connect(
  ConnectionURl,
  { useNewUrlParser: true },
  (error, client) => {
    if (error) {
      return console.log("Unable to connect to database");
    }

    const db = client.db(DatabaseName);

    // db.collection("users").insertOne({ name: "harshitha", age: 25 });

    db.collection("tasks").insertMany(
      [
        { description: "meditation", completed: "true" },
        { description: "Learn code", completed: "in progress" },
        { description: "set goals", completed: "in progress" },
      ],
      (error, data) => {
        if (error) {
          return console.log("Exited with an error");
        }
        console.log(data.ops);
      }
    );
    console.log("Connected with no error");
  }
);
