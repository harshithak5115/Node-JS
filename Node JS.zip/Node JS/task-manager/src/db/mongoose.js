const mongoose = require("mongoose");

const ConnectionURl = "mongodb://127.0.0.1:27017/task-manager-api";

mongoose.connect(ConnectionURl);

// const Task = mongoose.model("Task", {
//   description: { type: String, required: true, trim: true },
//   completed: { type: Boolean, required: true, default: false },
// });

// const task = new Task({
//   name: "Learn MongoDb",
//   completed: false,
// });

// task
//   .save()
//   .then(() => {
//     console.log(user);
//   })
//   .catch((error) => {
//     console.log("Error", error);
//   });
