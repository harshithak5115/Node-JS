const sgMail = require("@sendgrid/mail");

const sendgridAPIKey =
  "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";

sgMail.setApiKey(sendgridAPIKey);

const sendWelcomeEmail = (email, name) => {
  sgMail.send({
    to: email,
    from: "harshithak.5115@gmail.com",
    subject: "Thanks for creating account",
    text: `Thank you ${name} for creating account`,
  });
};

const cancelEmail = (email, name) => {
  sgMail.send({
    to: email,
    from: "harshithak.5115@gmail.com",
    subject: "we miss you",
    text: `Thank you ${name} for being with us`,
  });
};

module.exports = { sendWelcomeEmail, cancelEmail };
