const request = require("request");

const url = "https://goweather.herokuapp.com/weather/bengaluru";

request({ url: url, json: true }, (error, response) => {
  if (error) {
    console.log("system error");
  } else if (response.body.temperature.length <= 0) {
    console.log("Weather not found");
  } else {
    console.log(response.body.temperature);
  }
});

//
// Goal: Create a reusable function for getting the forecast
//
// 1. Setup the "forecast" function in utils/forecast.js
// 2. Require the function in app.js and call it as shown below
// 3. The forecast function should have three potential calls to callback:
//    - Low level error, pass string for error
//    - Coordinate error, pass string for error
//    - Success, pass forecast string for data (same format as from before)

const forecast = (data, callback) => {
  const url = "https://goweather.herokuapp.com/weather/" + data;
  request({ url: url, json: true }, (error, response) => {
    if (error) {
      callback("system error", undefined);
    } else if (response.body.temperature.length <= 0) {
      callback("Weather not found", undefined);
    } else {
      callback(undefined, response.body.temperature);
    }
  });
};

forecast("bengaluru", (error, data) => {
  if (error) {
    console.log("Error", error);
  } else {
    console.log("Data", data);
  }
});
