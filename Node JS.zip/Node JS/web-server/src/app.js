const path = require("path");
const express = require("express");
const hbs = require("hbs");

const forecast = require("../utils/forecast");

const app = express();

let publicDirectoryPath = path.join(__dirname, "../public");
let partials = path.join(__dirname, "../templates/partials");

app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "../templates/views"));

app.use(express.static(publicDirectoryPath));
hbs.registerPartials(partials);

app.get("", (req, res) => {
  res.render("index", {
    title: "Weather App",
    name: "Harshitha",
  });
});

app.get("/about", (req, res) => {
  res.render("about", { title: "About" });
});

app.get("/help", (req, res) => {
  res.render("help", { title: "Help" });
});

app.get("/weather", (req, res) => {
  if (!req.query.address) {
    res.send({ error: "Please enter valid location" });
  } else {
    forecast(req.query.address, (error, data) => {
      if (error) {
        return res.send({ error });
      }
      res.send({ data });
    });
  }
});

app.get("*", (req, res) => {
  res.render("404", { error: "Page not found" });
});

app.listen(3000, () => {
  console.log("App is up and running");
});
